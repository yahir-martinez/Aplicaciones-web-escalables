import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // Importa CommonModule si usas directivas como *ngIf o *ngFor

@Component({
  selector: 'app-header',
  standalone: true, // Convierte el componente en standalone
  imports: [CommonModule], // Importa módulos necesarios
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {}